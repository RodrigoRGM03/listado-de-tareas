document.addEventListener('DOMContentLoaded', () => {
    const taskForm = document.getElementById('taskForm');
    const taskList = document.getElementById('taskList');

    taskForm.addEventListener('submit', agregarTarea);
    taskList.addEventListener('click', manejarAccionTarea);

    cargarTareas();

    function agregarTarea(event) {
        event.preventDefault();

        const nombreTarea = document.getElementById('Trabajo').value;
        const responsable = document.getElementById('responsable').value;
        const fechaInicio = document.getElementById('Inicio').value;
        const fechaFin = document.getElementById('Fin').value;

        if (new Date(fechaFin) < new Date(fechaInicio)) {
            alert("La fecha de fin no puede ser menor a la fecha de inicio");
            return;
        }

        const tarea = {
            id: Date.now(),
            nombreTarea,
            responsable,
            fechaInicio,
            fechaFin,
            resuelta: false
        };

        const tareas = obtenerTareasDeLocalStorage();
        tareas.push(tarea);
        guardarTareasEnLocalStorage(tareas);

        renderizarTarea(tarea);
        taskForm.reset();
    }

    function renderizarTarea(tarea) {
        const ahora = new Date().toISOString().split('T')[0];
        let claseTarea = 'pendiente';
        if (tarea.resuelta) {
            claseTarea = 'resuelta';
        } else if (ahora > tarea.fechaFin) {
            claseTarea = 'vencida';
        }

        const li = document.createElement('li');
        li.className = `list-group-item d-flex justify-content-between align-items-center ${claseTarea}`;
        li.dataset.id = tarea.id;
        li.innerHTML = `
            <span>
                ${tarea.nombreTarea} (Responsable: ${tarea.responsable})<br>
                Fecha de inicio: ${tarea.fechaInicio} - Fecha de fin: ${tarea.fechaFin}
            </span>
            <div>
                ${tarea.resuelta ? '<button class="btn btn-warning btn-sm">Desmarcar</button>' : '<button class="btn btn-success btn-sm">Marcar como resuelta</button>'}
                <button class="btn btn-danger btn-sm">Eliminar</button>
            </div>
        `;
        taskList.appendChild(li);
    }

    function manejarAccionTarea(event) {
        const button = event.target;
        const li = button.closest('li');
        const id = li.dataset.id;
        let tareas = obtenerTareasDeLocalStorage();
        const tarea = tareas.find(tarea => tarea.id == id);

        if (button.classList.contains('btn-success')) {
            if (new Date(tarea.fechaFin) < new Date()) {
                alert("No se puede marcar como resuelta una tarea que ha vencido");
                return;
            }
            tarea.resuelta = true;
        } else if (button.classList.contains('btn-warning')) {
            tarea.resuelta = false;
        } else if (button.classList.contains('btn-danger')) {
            tareas = tareas.filter(tarea => tarea.id != id);
            guardarTareasEnLocalStorage(tareas);
            li.remove();
            return;
        }

        guardarTareasEnLocalStorage(tareas);
        li.remove();
        renderizarTarea(tarea);
    }

    function cargarTareas() {
        const tareas = obtenerTareasDeLocalStorage();
        tareas.forEach(tarea => renderizarTarea(tarea));
    }

    function obtenerTareasDeLocalStorage() {
        return JSON.parse(localStorage.getItem('tareas')) || [];
    }

    function guardarTareasEnLocalStorage(tareas) {
        localStorage.setItem('tareas', JSON.stringify(tareas));
    }
});
